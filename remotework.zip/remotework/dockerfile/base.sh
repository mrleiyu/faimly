#! /bin/sh

docker build -t composerw7 .
