#!/bin/bash


docker build -t composershop .