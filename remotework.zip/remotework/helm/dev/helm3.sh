#!/bin/bash


helm install


sudo helm --kubeconfig=/etc/rancher/k3s/k3s.yaml install devcenter ./dev

sudo helm --kubeconfig=/etc/rancher/k3s/k3s.yaml install devcenter ./dev --set nameOverride='devcenter' --set fullnameOverride='devcenter'