#!/bin/bash

# 安装docker
sudo apt-get install -y docker.io
sudo usermode -aG docker username

# 配置 dockerhub 镜像
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://y5iruiyg.mirror.aliyuncs.com"]
}
EOF

sudo systemctl daemon-reload
sudo systemctl restart docker


