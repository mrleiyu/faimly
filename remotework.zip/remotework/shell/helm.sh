#!/bin/bash
# 安装helm
sudo wget https://cdn.w7.cc/k3s/helm.tar.gz #下载
tar -zxvf helm.tar.gz #解压
cd ./helm.tar.gz
sudo chmod +x ./helm #加权限
mv ./helm /usr/local/bin/ #移动到全局


# 安装项目
# helm --kubeconfig=/etc/rancher/k3s/k3s.yaml install w7shop ../helm/dev
# helm repo add 123705-w7 https://repomanage.rdc.aliyun.com/helm_repositories/123705-w7 --username=EXxRMU --password=JXNJ8paOP3



docker build --pull --rm -f "docker/dev/dockerfile" -t remotework:latest "docker/dev"
helm uninstall dev
helm install dev ./helm/dev




