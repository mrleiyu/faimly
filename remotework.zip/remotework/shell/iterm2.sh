#!/bin/sh
# https://www.wandouip.com/t5i418086/

#plugins=(git autojump zsh-autosuggestions)


sudo add-apt-repository ppa:gnome-terminator
sudo apt-get update
sudo apt-get install terminator




