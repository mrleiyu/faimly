#!/bin/bash

# 官方文档链接 https://docs.rancher.cn/k3s/quick-start.html

# 安装k3s

curl -sfL https://docs.rancher.cn/k3s/k3s-install.sh |  INSTALL_K3S_MIRROR=cn sh -

curl -sfL http://rancher-mirror.cnrancher.com/k3s/k3s-install.sh | INSTALL_K3S_EXEC="server --docker" INSTALL_K3S_MIRROR=cn sh -