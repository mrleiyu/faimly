#
```
sudo  apt-get install -y php-dev
sudo pecl install mongodb

```