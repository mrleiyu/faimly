#!/bin/sh

docker run -d --name=phpmyadmin -e PMA_HOST=172.16.1.13 -e PMA_PORT=3306 -e PMA_USER=root -e PMA_PASSWORD=123456 -e MYSQL_ROOT_PASSWORD=123456 -e MYSQL_PASSWORD=123456 -p 3333:80 phpmyadmin/phpmyadmin

