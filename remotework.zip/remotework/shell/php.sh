#!/bin/bash

# php 
sudo apt-get install -y php
sudo apt-get install -y php-xml
sudo apt-get install -y php-curl
sudo apt-get install -y php-gd
sudo apt-get install -y php-bcmath

# composer
sudo apt-get install -y composer 
sudo composer config -g repo.packagist composer https://mirrors.aliyun.com/composer/ #用sudo
sudo composer global require hirak/prestissimo  # 下载加速器
sudo composer global require laravel/envoy  # 下载加速器

