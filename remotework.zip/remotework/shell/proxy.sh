#https://www.cnblogs.com/dreamboy/p/10675206.html
#http://www.suoniao.com/article/46297

#1.执行以下命令，安装TinyProxy

apt-get install tinyproxy

#2.安装成功后，修改配置文件
vim /etc/tinyproxy.conf
#修改以下两项：
#Port 8888 #代理服务器默认使用8888端口，也可以修改为其它端口
#Allow 127.0.0.1 #将127.0.0.1改成自己的外网IP，只有该IP才能连接，注意至少设置一个允许的IP

#3.启动TinyProxy
#启动 sudo service tinyproxy start
#重启 sudo service tinyproxy restart
#停止 sudo service tinyproxy stop



##https://www.cnblogs.com/dgjnszf/p/11752817.html
#https://github.com/fengyouchao/pysocks/raw/master/socks5.py