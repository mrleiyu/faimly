#!/bin/bash


https://www.cnblogs.com/pyexile/p/11700541.html 很多软件
# 1.1
git clone https://github.com/wszqkzqk/deepin-wine-ubuntu.git
# 1.2 (或者这个地址)
git clone https://gitee.com/wszqkzqk/deepin-wine-for-ubuntu.git

# 2. 
cd deepin-wine-ubuntu/
sh install.sh 

# 3. QQ
wget https://gitee.com/wszqkzqk/deepin-wine-containers-for-ubuntu/raw/master/deepin.com.qq.im_9.1.8deepin0_i386.deb
sudo dpkg -i deepin.com.qq.office_2.0.0deepin4_i386.deb


# linux qq
#https://im.qq.com/linuxqq/download.html
 #~/.config/tencent-qq/