#!/bin/bash

sudo apt-get install -y rdesktop

#
#命令参数常用的有：
#-u用户名
#-p密码
#-n客户端主机名（显示windows任务管理器中的连接客户端名）
#-g桌面大小（ 宽＊ 高）[也可以用 x(小写的X)]
#-f全屏模式,从全屏模式切换出来按Ctrl+Alt+Enter
#-a连接颜色深度（最高到16位），一般选16才会显示真彩色（window7支持32位）
#-0数字0表示连接上windows控制台，等效mstsc/console命令

#链接：https://www.jianshu.com/p/54be7d024e4c
#
#
##
#rdesktop -f -a 16  192.168.1.112