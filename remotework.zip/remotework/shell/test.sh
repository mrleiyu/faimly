#!/bin/bash
curl -sfL https://docs.rancher.cn/k3s/k3s-install.sh |  INSTALL_K3S_MIRROR=cn sh -