#/bin/bash
#https://cnrancher.github.io/docs-octopus/docs/cn/install
#https://github.com/cnrancher/docs-octopus


kubectl create ns octopus-system

helm install --namespace octopus-system myapp octopus/octopus

helm status myapp -n octopus-system

#helm delete myapp -n octopus-system