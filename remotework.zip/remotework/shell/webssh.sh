#!/bin/bash

pip install -i https://mirrors.aliyun.com/pypi/simple webssh


#启动
wssh