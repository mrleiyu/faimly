#!/bin/bash

sudo apt-get install -y zsh

sh -c "$(curl -fsSL https://gitee.com/mirrors/oh-my-zsh/raw/master/tools/install.sh)"

git clone https://github.com/zsh-users/zsh-autosuggestions ~/.oh-my-zsh/plugins/zsh-autosuggestions

#source ~/.zsh/zsh-autosuggestions/zsh-autosuggestions.zsh
# 这步需要
#plugins=(git zsh-autosuggestions)


